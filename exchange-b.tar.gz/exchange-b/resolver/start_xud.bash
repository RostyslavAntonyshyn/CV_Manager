source ~/.bash_profile
currentwd=`pwd`
cd $XUDHOME
./bin/xud  -x $currentwd
